Requests based token generator for discord with a hcaptcha bypass. It kinda works ig just use hq proxies..

FEATURES:

    Run up to 100 Threads at once
    Proxy support [ Https | All proxy combinations ]
    AI Solver / Bypass
    4 SMS PROVIDERS
    Kopeechka for mails ;-;

Service Provider Options:
    email:
        https://kopeechka.store/ - the standard option, should be used almost always
        https://mail.tm/en/ - free, most of the time detected by discord, but they sometimes have undetected domains
    phone:
        https://5sim.net/ - recommended
        https://sms-activate.org/en/
        -------------------------------------------------
        (officially unsupported, if you're having issues with these, try using the other providers)
        http://smspva.com/
        https://activation.pw/
